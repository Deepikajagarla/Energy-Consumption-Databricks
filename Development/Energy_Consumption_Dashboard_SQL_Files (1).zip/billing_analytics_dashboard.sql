-- Billing Analytics Dashboard
SELECT
    region_name,
    city_name,
    customer_category,
    meter_type,
    ROUND(SUM(monthly_bill),2) AS total_bill,
    ROUND(AVG(monthly_bill),2) AS average_bill,
    ROUND(AVG(unit_rate),2) AS average_unit_rate,
    ROUND(AVG(peak_rate),2) AS average_peak_rate,
    ROUND(AVG(offpeak_rate),2) AS average_offpeak_rate
FROM gold_catalog.gold_sch_gold_sch.fact_energy_usage
GROUP BY region_name, city_name, customer_category, meter_type
ORDER BY total_bill DESC;