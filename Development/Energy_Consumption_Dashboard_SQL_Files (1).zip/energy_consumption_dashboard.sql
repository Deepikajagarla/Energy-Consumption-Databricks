-- Energy Consumption Dashboard
SELECT
    region_name,
    city_name,
    customer_category,
    ROUND(SUM(energy_usage_kwh),2) AS total_energy_usage,
    ROUND(AVG(energy_usage_kwh),2) AS average_energy_usage,
    ROUND(MAX(peak_demand_kw),2) AS peak_demand
FROM gold_catalog.gold_sch_gold_sch.fact_energy_usage
GROUP BY region_name, city_name, customer_category
ORDER BY total_energy_usage DESC;