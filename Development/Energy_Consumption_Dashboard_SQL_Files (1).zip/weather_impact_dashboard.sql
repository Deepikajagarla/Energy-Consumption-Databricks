-- Weather Impact Dashboard
SELECT
    region_name,
    city_name,
    ROUND(AVG(temperature_celsius),2) AS avg_temperature,
    ROUND(AVG(humidity_percent),2) AS avg_humidity,
    ROUND(AVG(rainfall_mm),2) AS avg_rainfall,
    ROUND(AVG(energy_usage_kwh),2) AS avg_energy_usage,
    ROUND(MAX(peak_demand_kw),2) AS peak_demand
FROM gold_catalog.gold_sch_gold_sch.fact_energy_usage
GROUP BY region_name, city_name
ORDER BY avg_energy_usage DESC;