-- Device Monitoring Dashboard
SELECT
    device_category,
    device_brand,
    maintenance_status,
    COUNT(*) AS total_devices,
    ROUND(AVG(runtime_hours),2) AS avg_runtime,
    ROUND(AVG(device_power_kw),2) AS avg_power,
    ROUND(AVG(energy_draw_kwh),2) AS avg_energy_draw,
    ROUND(AVG(efficiency_ratio),2) AS avg_efficiency
FROM gold_catalog.gold_sch_gold_sch.dim_device
GROUP BY device_category, device_brand, maintenance_status
ORDER BY total_devices DESC;